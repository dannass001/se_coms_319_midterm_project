# se_coms_319_midterm_project
Midterm project for SE/COM S 319 class

Webpage: https://dannass001.github.io/se_coms_319_midterm_project/index.html 
